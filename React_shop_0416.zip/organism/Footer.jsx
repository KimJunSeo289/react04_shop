import React from 'react'

const Footer = () => {
  return (
    <footer>
      <p>Footer</p>
    </footer>
  )
}

export default Footer
