import React from 'react'

const NotFound = () => {
  return (
    <main>
      <h2>NotFound</h2>
    </main>
  )
}

export default NotFound
