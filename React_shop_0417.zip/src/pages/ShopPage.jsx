import React from 'react'

const ShopPage = () => {
  return (
    <main>
      <h2>ShopPage</h2>
    </main>
  )
}

export default ShopPage
