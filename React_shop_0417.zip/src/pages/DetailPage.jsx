import React, { useEffect, useState } from 'react'
import { useLoaderData } from 'react-router-dom'
import css from './DetailPage.module.css'
import { formatCurrency } from '@/utils/features'
import ProductCard from '@/components/ProductCard'
import { getProductsData } from '@/api/productsApi'

const DetailPage = () => {
  const [products, setProducts] = useState([])

  const { product, relatedProducts } = useLoaderData()
  const [activeTab, setActiveTab] = useState('description')
  console.log('DetailPage:product', product)
  console.log('DetailPage:relatedProducts', relatedProducts)

  useEffect(() => {
    const fetchProducts = async () => {
      try {
        const data = await getProductsData(`category=new&_limit=3`)
        console.log('data----', data)

        setProducts(data)
      } catch (err) {
        console.log(err)
      }
    }

    fetchProducts()
  }, [])

  return (
    <main>
      <h2>DetailPage</h2>
      <div className={css.detailCon}>
        <div className={css.imgWrap}>
          <img src={`/public/img/${product.img}`} alt={product.title} />
          {product.discount > 0 && <p className={css.discount}>{product.discount} %</p>}
        </div>
        <div className={css.infoWrap}>
          <p className={css.title}>{product.title}</p>
          <p className={css.price}>{formatCurrency(product.price)}</p>
          <p className={css.category}>{product.category}</p>
          <div className={css.btnWrap}>
            <div className={css.counterArea}>
              <button>-</button>
              <span>1</span>
              <button>+</button>
            </div>
            <button className={css.addBtn}>장바구니 담기</button>
          </div>
        </div>
      </div>

      <div className={css.tabMenu}>
        <button
          className={activeTab === 'description' ? css.active : ''}
          onClick={() => setActiveTab('description')}
        >
          Description
        </button>
        <button
          className={activeTab === 'additional' ? css.active : ''}
          onClick={() => setActiveTab('additional')}
        >
          Additional Information
        </button>
        <button
          className={activeTab === 'reviews' ? css.active : ''}
          onClick={() => setActiveTab('reviews')}
        >
          Reviews(0)
        </button>
      </div>

      <div className={css.tabContent}>
        {activeTab === 'description' && (
          <p>
            Description Lorem ipsum dolor sit amet consectetur adipisicing elit. Nesciunt ad, fugiat
            quam impedit nulla debitis dignissimos hic explicabo? Voluptatibus veniam ut nulla
            soluta asperiores veritatis accusamus quae consectetur quo ipsum!
          </p>
        )}
        {activeTab === 'additional' && <p>Additional Information</p>}
        {activeTab === 'reviews' && <p>reviews</p>}
      </div>

      <div className={css.similarItemsCon}>
        {products.map(data => (
          <li key={data.id}>
            <ProductCard data={data} />
          </li>
        ))}
      </div>
    </main>
  )
}

export default DetailPage
