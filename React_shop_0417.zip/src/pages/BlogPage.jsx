import React from 'react'

const BlogPage = () => {
  return (
    <main>
      <h2>BlogPage</h2>
    </main>
  )
}

export default BlogPage
