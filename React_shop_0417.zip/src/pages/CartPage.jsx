import React from 'react'

const CartPage = () => {
  return (
    <main>
      <h2>CartPage</h2>
    </main>
  )
}

export default CartPage
